from __future__ import annotations

import hashlib
import html
import json
import re
from collections import Counter
from datetime import datetime, timezone, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parent
TZ = timezone(timedelta(hours=8))
IMAGE_MAP = json.loads((ROOT / "sources" / "images_manifest.json").read_text(encoding="utf-8"))
DISCOVERY = json.loads((ROOT / "sources" / "discovery.json").read_text(encoding="utf-8"))
HTTP_LOG = json.loads((ROOT / "sources" / "http_log.json").read_text(encoding="utf-8"))


def now() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def esc(value) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def walk_modules(nodes):
    for module in nodes or []:
        yield module
        yield from walk_modules(module.get("children"))


def module_title(module: dict) -> str:
    typ = module.get("type")
    if isinstance(typ, dict) and typ.get("nameZh"):
        return typ["nameZh"]
    return module.get("nameZh") or f"未命名模块（ID {module.get('id')}）"


def direct_courses(module: dict) -> list[dict]:
    return module.get("planCourses") or []


def replace_image_sources(markup: str, unavailable: list[str]) -> str:
    def repl(match):
        src = html.unescape(match.group(2)).strip()
        item = IMAGE_MAP.get(src)
        if item and item.get("access_status") == "available":
            rel = "../" + item["relative_path"]
            return match.group(1) + esc(rel) + match.group(3)
        unavailable.append(src)
        return match.group(1) + "" + match.group(3)

    return re.sub(r"(\bsrc\s*=\s*)(['\"])([^'\"]+)(\2)", lambda m: replace_image_attr(m, unavailable), markup, flags=re.I)


def replace_image_attr(match, unavailable: list[str]) -> str:
    # Separate helper to retain the original quote style.
    src = html.unescape(match.group(3)).strip()
    item = IMAGE_MAP.get(src)
    if item and item.get("access_status") == "available":
        rel = "../" + item["relative_path"]
        return match.group(1) + match.group(2) + esc(rel) + match.group(4)
    unavailable.append(src)
    return match.group(1) + match.group(2) + match.group(4)


STYLE = """<style>
:root{color-scheme:light}body{max-width:1180px;margin:24px auto;padding:0 22px;color:#182a3a;font:15px/1.62 "Segoe UI","Microsoft YaHei",sans-serif;background:#fff}
h1{font-size:26px;margin:8px 0 6px}h2{font-size:22px;margin:28px 0 12px;border-bottom:2px solid #315d76;padding-bottom:6px}h3{font-size:18px;margin:24px 0 8px;color:#1d4960}h4{font-size:15px;margin:17px 0 7px;color:#315d76}
.meta,.rule,.source-note{background:#f3f7f9;border:1px solid #dce6eb;border-radius:7px;padding:10px 13px;margin:9px 0 15px}.meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:4px 16px}.tag{display:inline-block;border-radius:12px;background:#e6f0f4;padding:2px 9px;margin:2px 5px 2px 0;font-size:12px;color:#24495e}
.document-content img{max-width:100%;height:auto;display:block;margin:12px auto}.document-content table{border-collapse:collapse;max-width:100%;margin:10px 0}.document-content td,.document-content th{border:1px solid #aab9c1;padding:5px 8px}
.module{margin:10px 0 18px;border-left:2px solid #d5e2e9;padding-left:12px}.module h4{margin-top:14px}.module-rule{white-space:pre-wrap;color:#3c4d58;margin:3px 0 8px}.course-table{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0 12px;table-layout:auto}.course-table th,.course-table td{border:1px solid #d5dfe4;padding:5px 7px;vertical-align:top;text-align:left}.course-table th{background:#edf3f6}.course-table tr:nth-child(even){background:#fbfcfd}.course-table td.code,.course-table td.credit,.course-table td.term{white-space:nowrap}.muted{color:#637581}.course-remark{white-space:pre-wrap;color:#55636b}.topnav{margin:12px 0 18px}.topnav a,.source-note a{color:#126a88;margin-right:13px}
@media print{body{max-width:none;margin:0;padding:0 6mm;font-size:10pt}h2,h3,h4{break-after:avoid}.module{break-inside:avoid}.course-table{font-size:8.5pt}tr{break-inside:avoid}.topnav{display:none}.document-content img{max-height:240mm}}
</style>"""


def rule_text(module: dict) -> str:
    info = module.get("requireInfo") or {}
    limit = module.get("limitInfo") or {}
    values = []
    for key, label in [
        ("requiredCredits", "要求学分"),
        ("requiredCourseNum", "要求课程数"),
        ("requiredSubModuleNum", "要求子模块数"),
        ("postCreditsRequired", "研究生课程学分要求"),
        ("postRequiredCourseNum", "研究生课程门数要求"),
        ("integrationCreditsRequired", "融合课程学分要求"),
        ("integrationRequiredCourseNum", "融合课程门数要求"),
    ]:
        value = info.get(key)
        if value not in (None, 0, 0.0, "", "0"):
            values.append(f"{label}：{value}")
    if info.get("requireAll"):
        values.append("要求全部修读")
    if info.get("requireAny"):
        values.append("按模块选修")
    for key, label in [("creditsUpperLimit", "学分上限"), ("courseNumUpperLimit", "课程数上限")]:
        value = limit.get(key)
        if value not in (None, 0, 0.0, ""):
            values.append(f"{label}：{value}")
    if not values and info.get("showRequiredCredits"):
        values.append(f"显示学分要求：{info['showRequiredCredits']}")
    return "；".join(values)


def render_course_table(courses: list[dict], course_ids: list[str]) -> str:
    if not courses:
        return ""
    parts = ["<table class=\"course-table\"><thead><tr><th>课号</th><th>课程名称</th><th>学分</th><th>要求</th><th>开课学期</th><th>建议学期</th><th>总学时</th><th>备注</th></tr></thead><tbody>"]
    for i, row in enumerate(courses):
        course = row.get("course") or {}
        code = course.get("code") or ""
        name = course.get("nameZh") or course.get("nameEn") or "（课程名称缺失）"
        credits = row.get("credits") if row.get("credits") is not None else course.get("credits")
        period = row.get("periodInfo") or course.get("periodInfo") or {}
        total_period = period.get("total")
        mandatory = "必修" if row.get("compulsory") is True else "非必修" if row.get("compulsory") is False else ""
        terms = row.get("termsText") or ""
        suggested = row.get("suggestTermsText") or ""
        remark = row.get("remark") or course.get("remark") or ""
        cid = course_ids[i]
        parts.append(
            f"<tr data-plan-course-id=\"{esc(cid)}\"><td class=\"code\">{esc(code) or '—'}</td>"
            f"<td>{esc(name)}{('<div class=\"muted\">' + esc(course.get('nameEn')) + '</div>') if course.get('nameEn') else ''}</td>"
            f"<td class=\"credit\">{esc(credits) or '—'}</td><td>{mandatory}</td>"
            f"<td class=\"term\">{esc(terms) or '—'}</td><td class=\"term\">{esc(suggested) or '—'}</td>"
            f"<td>{esc(total_period) or '—'}</td><td><div class=\"course-remark\">{esc(remark)}</div></td></tr>"
        )
    parts.append("</tbody></table>")
    return "".join(parts)


def render_modules(nodes: list[dict], depth: int, audit: dict) -> str:
    out = []
    for module in nodes or []:
        title = module_title(module)
        courses = direct_courses(module)
        if courses:
            course_ids = [str((c.get("course") or {}).get("id") or c.get("id") or "") for c in courses]
            expected_ids = [str((c.get("course") or {}).get("id") or c.get("id") or "") for c in (module.get("realPlanCourses") or [])]
            if course_ids != expected_ids:
                audit["plan_real_course_identity_match"] = False
            audit["rendered_direct_course_rows"] += len(courses)
            audit["rendered_course_ids"].extend(course_ids)
        level = module.get("level") or ""
        heading = "h3" if depth == 0 else "h4"
        out.append(f"<section class=\"module\" data-module-id=\"{esc(module.get('id'))}\"><{heading}>{esc(title)} <span class=\"muted\">{('· 层级 ' + esc(level)) if level else ''}</span></{heading}>")
        details = []
        requirement = rule_text(module)
        if requirement:
            details.append(requirement)
        for key, label in [("labelText", "说明"), ("commentText", "补充"), ("remark", "备注")]:
            value = module.get(key)
            if value:
                details.append(f"{label}：{value}")
        if details:
            out.append("<div class=\"module-rule\">" + "<br>".join(esc(x) for x in details) + "</div>")
        if courses:
            out.append(render_course_table(courses, course_ids))
        out.append(render_modules(module.get("children") or [], depth + 1, audit))
        out.append("</section>")
    return "".join(out)


def render_content_paragraphs(doc: dict, unavailable: list[str]) -> str:
    paragraphs = (doc.get("programContent") or {}).get("paragraphs") or []
    if isinstance(paragraphs, dict):
        paragraphs = []
    out = []
    for paragraph in paragraphs:
        title = paragraph.get("titleZh") or paragraph.get("titleEn")
        content = paragraph.get("contentZh") or paragraph.get("contentEn") or ""
        if not title and not content:
            continue
        out.append(f"<section class=\"document-content\"><h2>{esc(title or '培养方案正文')}</h2>")
        if content:
            out.append(replace_image_sources(content, unavailable))
        out.append("</section>")
    return "".join(out)


def render_program(doc: dict, source_url: str, raw_rel: str, out_path: Path, is_public: bool = False) -> dict:
    model = doc.get("model") or {}
    department = model.get("department") or {}
    major = model.get("major") or {}
    cultivate = model.get("cultivateType") or {}
    student = model.get("stdType") or {}
    degree = model.get("degreeType") or {}
    modules = doc.get("courseModules") or []
    all_modules = list(walk_modules(modules))
    direct_rows = [course for module in all_modules for course in direct_courses(module)]
    top_level_direct_rows = sum(len(direct_courses(module)) for module in modules)
    course_keys = []
    for course in direct_rows:
        c = course.get("course") or {}
        course_keys.append(str(c.get("code") or c.get("id") or c.get("nameZh") or ""))
    expected_ids = []
    for module in all_modules:
        expected_ids.extend(str((c.get("course") or {}).get("id") or c.get("id") or "") for c in direct_courses(module))
    audit = {"rendered_direct_course_rows": 0, "rendered_course_ids": [], "plan_real_course_identity_match": True}
    unavailable_images: list[str] = []
    content = render_content_paragraphs(doc, unavailable_images)
    course_tree = render_modules(modules, 0, audit)
    if audit["rendered_direct_course_rows"] != len(direct_rows):
        raise ValueError(f"Course row rendering mismatch for {model.get('id')}: {audit['rendered_direct_course_rows']} vs {len(direct_rows)}")
    if Counter(audit["rendered_course_ids"]) != Counter(expected_ids):
        raise ValueError(f"Rendered plan-course identities mismatch for {model.get('id')}")
    if not audit["plan_real_course_identity_match"]:
        raise ValueError(f"planCourses/realPlanCourses identity mismatch for {model.get('id')}")
    if unavailable_images:
        raise ValueError(f"Offline image missing for {model.get('id')}: {unavailable_images}")

    title = model.get("nameZh") or "培养方案"
    intro = "2026级公共方案：应与学生所属学院方案配合阅读。" if is_public else "专业方案需与公共方案（ID 466）配合阅读，公共课程要求以公共方案为准。"
    page = ["<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>", esc(title), "</title>", STYLE, "</head><body>"]
    page.append(f"<nav class=\"topnav\"><a href=\"../index.html\">培养方案目录</a><a href=\"../{esc(raw_rel)}\">原始JSON</a><a href=\"{esc(source_url)}\" rel=\"noreferrer\">教务系统来源</a></nav>")
    page.append(f"<h1>{esc(title)}</h1><p>{esc(intro)}</p>")
    page.append("<div class=\"meta\">")
    items = [
        ("方案ID", model.get("id")), ("年级", model.get("grade")), ("学院/系", department.get("nameZh")),
        ("专业", major.get("nameZh")), ("学生类别", student.get("nameZh")), ("培养类型", cultivate.get("nameZh")),
        ("学位", degree.get("nameZh")), ("培养年限", model.get("duration")), ("学期数", model.get("termsCount")),
        ("生效日期", model.get("effectiveOn")), ("最近更新", model.get("updatedDateTime")), ("审核状态", model.get("auditState")),
    ]
    for label, value in items:
        if value not in (None, ""):
            page.append(f"<div><b>{esc(label)}：</b>{esc(value)}</div>")
    page.append(f"<div><b>课程树：</b>{len(all_modules)} 个模块；直接课程 {len(direct_rows)} 行（{len(set(course_keys))} 个唯一代码/课程）</div></div>")
    page.append(content)
    page.append("<section><h2>课程模块与直接课程</h2><p class=\"source-note\">每个模块列出其原始 <code>planCourses</code> 直接课程；父模块本身的课程也保留，不以子模块汇总替代。模块规则据官方详情 JSON 的 requireInfo、说明与备注字段排版。</p>")
    page.append(course_tree)
    page.append("</section><footer class=\"source-note\">离线阅读版根据教务系统公开详情 JSON 排版。原始JSON与官网来源链接见页首；本文件不是教务系统签章版文件。</footer></body></html>")
    markup = "".join(page)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(markup, encoding="utf-8")
    all_codes_present = all(code in markup for code in course_keys if code)
    if not all_codes_present:
        raise ValueError(f"A source course code is absent from the rendered HTML for {model.get('id')}")
    images = []
    for src, data in IMAGE_MAP.items():
        if str(model.get("id")) in data.get("referenced_by_program_ids", []) and data.get("access_status") == "available":
            images.append(data["relative_path"])
    return {
        "id": model.get("id"), "name": title, "grade": model.get("grade"),
        "major": major.get("nameZh"), "major_id": major.get("id"),
        "department": department.get("nameZh"), "department_id": department.get("id"),
        "student_type": student.get("nameZh"), "cultivate_type": cultivate.get("nameZh"),
        "degree_type": degree.get("nameZh"), "duration_years": model.get("duration"),
        "terms_count": model.get("termsCount"), "effective_on": model.get("effectiveOn"),
        "updated_at": model.get("updatedDateTime"), "audit_state": model.get("auditState"),
        "source_url": source_url, "raw_path": raw_rel,
        "raw_bytes": (ROOT / raw_rel).stat().st_size, "raw_sha256": sha256(ROOT / raw_rel),
        "printable_html": str(out_path.relative_to(ROOT)).replace("\\", "/"),
        "printable_bytes": out_path.stat().st_size, "printable_sha256": sha256(out_path),
        "module_count": len(all_modules), "top_level_module_count": len(modules),
        "nested_module_count": len(all_modules) - len(modules),
        "direct_course_rows": len(direct_rows),
        "direct_course_rows_on_top_level_modules": top_level_direct_rows,
        "direct_course_rows_in_nested_modules": len(direct_rows) - top_level_direct_rows,
        "unique_course_keys": len(set(course_keys)), "course_code_occurrences": course_keys,
        "course_rows_by_module": [
            {"module_id": x.get("id"), "name": module_title(x), "level": x.get("level"),
             "direct_course_rows": len(direct_courses(x)),
             "direct_course_codes": [((c.get("course") or {}).get("code") or (c.get("course") or {}).get("nameZh") or "") for c in direct_courses(x)],
             "reference_course_module_id": x.get("referenceCourseModuleAssoc"),
             "copy_course_module_id": x.get("copyCourseModuleAssoc")}
            for x in all_modules
        ],
        "course_completeness": {
            "source_plan_course_rows": len(direct_rows),
            "rendered_plan_course_rows": audit["rendered_direct_course_rows"],
            "all_direct_rows_rendered": audit["rendered_direct_course_rows"] == len(direct_rows),
            "planCourses_matches_realPlanCourses_by_module": audit["plan_real_course_identity_match"],
            "all_source_course_codes_present": all_codes_present,
        },
        "image_relative_paths": images,
    }


def log_entry_for(url: str) -> dict:
    for item in HTTP_LOG:
        if item.get("url") == url:
            return item
    raise KeyError(f"Missing HTTP audit record: {url}")


def main() -> None:
    search_rows = DISCOVERY.get("search_rows", [])
    expected_count = DISCOVERY.get("search_row_count")
    if len(search_rows) != expected_count or expected_count != 11:
        raise ValueError(f"Search completeness check failed: rows={len(search_rows)}, recorded={expected_count}")
    if len({row.get("ID") for row in search_rows}) != len(search_rows):
        raise ValueError("Duplicate program ID in public search result")
    if any(str(row.get("YEARS")) != "2026" or str(row.get("DEPART_IDS")) != "2571" for row in search_rows):
        raise ValueError("Search result contains an out-of-scope row")

    program_entries = []
    for row in search_rows:
        pid = int(row["ID"])
        raw_rel = f"programs/{pid}.json"
        raw_path = ROOT / raw_rel
        if not raw_path.is_file():
            raise FileNotFoundError(raw_path)
        doc = read_json(raw_path)
        model = doc.get("model") or {}
        if model.get("id") != pid or model.get("nameZh") != row.get("NAME_ZH"):
            raise ValueError(f"List/detail mismatch for {pid}: {row.get('NAME_ZH')} != {model.get('nameZh')}")
        if (model.get("department") or {}).get("id") != 2571 or str(model.get("grade")) != "2026":
            raise ValueError(f"Out-of-scope detail for {pid}")
        source_url = f"https://fdjwgl.fudan.edu.cn/manager/bizType/2/major-program-search/info/{pid}"
        filename = f"{pid}_{re.sub(r'[^\w\-（）()]+', '_', model.get('nameZh') or 'plan')}.html"
        html_path = ROOT / "printable" / filename
        entry = render_program(doc, source_url, raw_rel, html_path)
        entry["search_row"] = row
        entry["source_download"] = log_entry_for(source_url)
        # Public module references are established later using the downloaded public tree.
        program_entries.append(entry)

    public_rel = "public/466.json"
    public_doc = read_json(ROOT / public_rel)
    public_model = public_doc.get("model") or {}
    if (public_model.get("id"), public_model.get("grade"), public_model.get("auditState")) != (466, "2026", "ACCEPTED"):
        raise ValueError("The downloaded public scheme does not match the 2026 accepted public scheme")
    public_url = "https://fdjwgl.fudan.edu.cn/manager/bizType/2/public-program-search/info/466"
    public_filename = "466_2026级_公共方案.html"
    public_html_path = ROOT / "printable" / public_filename
    public_entry = render_program(public_doc, public_url, public_rel, public_html_path, is_public=True)
    public_entry["source_download"] = log_entry_for(public_url)

    public_module_ids = {m.get("id") for m in walk_modules(public_doc.get("courseModules"))}
    for entry in program_entries:
        referenced = {m.get("referenceCourseModuleAssoc") for m in walk_modules(read_json(ROOT / entry["raw_path"]).get("courseModules")) if m.get("referenceCourseModuleAssoc")}
        copied = {m.get("copyCourseModuleAssoc") for m in walk_modules(read_json(ROOT / entry["raw_path"]).get("courseModules")) if m.get("copyCourseModuleAssoc")}
        matches = sorted((referenced | copied) & public_module_ids)
        entry["public_program_id"] = 466
        entry["public_program_name"] = public_model.get("nameZh")
        entry["public_module_reference_matches"] = matches
        if not matches:
            raise ValueError(f"No public module reference tie found for major plan {entry['id']}")

    # Image mapping is set from official content. Require each referenced image be local and hashed.
    image_entries = list(IMAGE_MAP.values())
    missing_images = [x for x in image_entries if x.get("access_status") != "available" or not (ROOT / x.get("relative_path", "")).is_file()]
    if missing_images:
        raise ValueError(f"Image completeness failure: {missing_images}")

    # Make an offline landing page for all 11 major schemes and their shared public scheme.
    idx = ["<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>复旦大学物理学系 2026 级培养方案</title>", STYLE, "</head><body>"]
    idx.append("<h1>复旦大学物理学系 2026 级培养方案</h1><p>官方筛选结果共 11 份系级方案，全部详情均已下载。完整培养方案由对应系级方案与公共方案共同构成；公共方案 ID 466 与 11 份系级方案的模块引用均有交叉匹配。</p>")
    idx.append("<p class=\"source-note\">离线阅读版由公开详情 JSON 排版。原始 JSON、每项来源链接、下载状态与 SHA-256 见 <a href=\"program_manifest.json\">清单</a>；原始检索页与HTTP记录在 <code>sources/</code>。页面中课程表按每个课程模块的直接 planCourses 输出，包含父模块直接挂载的课程。</p>")
    idx.append("<h2>系级培养方案</h2><table class=\"course-table\"><thead><tr><th>方案名称</th><th>类别</th><th>学位 / 年限</th><th>生效 / 更新</th><th>状态</th><th>课程与原文</th><th>原始JSON</th><th>官网</th></tr></thead><tbody>")
    for entry in program_entries:
        idx.append("<tr><td><b>" + esc(entry["name"]) + "</b><div class=\"muted\">ID " + esc(entry["id"]) + " · " + esc(entry["student_type"] or "") + " · " + esc(entry["cultivate_type"] or "") + "</div></td>")
        idx.append(f"<td>{esc(entry['major'] or '')}</td><td>{esc(entry['degree_type'] or '')} / {esc(entry['duration_years'] or '')} 年</td><td>{esc(entry['effective_on'] or '')}<div class=\"muted\">更新 {esc(entry['updated_at'] or '')}</div></td><td>{esc(entry['audit_state'] or '')}</td>")
        idx.append(f"<td>{entry['direct_course_rows']} 行 · <a href=\"{esc(entry['printable_html'])}\">离线阅读</a></td><td><a href=\"{esc(entry['raw_path'])}\">JSON</a></td><td><a href=\"{esc(entry['source_url'])}\">教务系统</a></td></tr>")
    idx.append("</tbody></table><h2>全校公共方案</h2><table class=\"course-table\"><thead><tr><th>方案</th><th>版本</th><th>审核状态</th><th>课程行</th><th>离线阅读</th><th>原始JSON</th><th>官网</th></tr></thead><tbody>")
    idx.append(f"<tr><td>{esc(public_entry['name'])}（ID 466）</td><td>{esc(public_entry['effective_on'])} / 更新 {esc(public_entry['updated_at'])}</td><td>{esc(public_entry['audit_state'])}</td><td>{public_entry['direct_course_rows']}</td><td><a href=\"{esc(public_entry['printable_html'])}\">离线阅读</a></td><td><a href=\"{esc(public_entry['raw_path'])}\">JSON</a></td><td><a href=\"{esc(public_entry['source_url'])}\">教务系统</a></td></tr>")
    idx.append("</tbody></table><p class=\"source-note\">培养方案查询入口：<a href=\"https://fdjwgl.fudan.edu.cn/manager/bizType/2/page-center/major-program-search-view?skipAuth=1\">复旦教务系统培养方案查询</a></p></body></html>")
    index_path = ROOT / "index.html"
    index_path.write_text("".join(idx), encoding="utf-8")

    sources_by_url = {item.get("url"): item for item in HTTP_LOG}
    search_source_url = DISCOVERY["discovery"]["college_search_url"]
    search_source = sources_by_url[search_source_url]
    landing_url = DISCOVERY["discovery"]["public_landing_url"]
    landing_source = sources_by_url[landing_url]
    public_entry["public_program_id"] = 466
    manifest = {
        "created_at": now(),
        "scope": {
            "department_name": "物理学系", "department_id": 2571, "department_code": "019",
            "grade_filter": "2026", "result_count": len(search_rows),
            "search_pages": len(DISCOVERY.get("pagination", [])),
            "search_total_rows": expected_count,
            "search_page_metadata": DISCOVERY.get("pagination", []),
        },
        "discovery": {
            "landing_url": landing_url, "landing_path": "sources/landing.html",
            "landing_http_status": landing_source.get("http_status"), "landing_sha256": landing_source.get("sha256"),
            "search_url": search_source_url, "search_path": "sources/college_search_page_1.json",
            "search_http_status": search_source.get("http_status"), "search_sha256": search_source.get("sha256"),
            "department_filter_evidence": "入口页面直接包含选项 value=2571、label=019: 物理学系；查询页以 YEARS=2026、DEPART_IDS=2571 筛选。",
            "completeness": "单页返回11条，_page_.totalRows=11、totalPages=1；逐项详情ID/名称/系别/年级与列表一致。",
        },
        "public_program": public_entry,
        "college_programs": program_entries,
        "public_program_association": {
            "program_id": 466, "name": public_model.get("nameZh"), "verified_for_major_program_count": len(program_entries),
            "all_major_programs_reference_public_modules": all(bool(x["public_module_reference_matches"]) for x in program_entries),
            "method": "将各系级方案的 referenceCourseModuleAssoc/copyCourseModuleAssoc 与 public/466.json 中的 courseModules.id 对照；11/11 均有命中。",
            "reference_matches_by_program": {str(x["id"]): x["public_module_reference_matches"] for x in program_entries},
        },
        "images": IMAGE_MAP,
        "access_and_offline_status": {
            "authentication": "所有请求均为匿名标准HTTP GET；未使用登录、凭证或替代接口。",
            "major_details_available": f"{sum(1 for x in program_entries if x['source_download'].get('access_status') == 'available')}/{len(program_entries)}",
            "public_details_available": public_entry["source_download"].get("access_status") == "available",
            "image_assets_available": f"{sum(1 for x in image_entries if x.get('access_status') == 'available')}/{len(image_entries)}",
            "offline_html_generated": True,
            "pdf": "入口未返回PDF；离线阅读版为HTML，正文图片已按相对路径保存。原JSON完整保留。",
            "restricted_or_missing": [],
        },
        "source_files": {
            "http_log": {"path": "sources/http_log.json", "bytes": (ROOT / "sources" / "http_log.json").stat().st_size, "sha256": sha256(ROOT / "sources" / "http_log.json")},
            "discovery": {"path": "sources/discovery.json", "bytes": (ROOT / "sources" / "discovery.json").stat().st_size, "sha256": sha256(ROOT / "sources" / "discovery.json")},
            "image_manifest": {"path": "sources/images_manifest.json", "bytes": (ROOT / "sources" / "images_manifest.json").stat().st_size, "sha256": sha256(ROOT / "sources" / "images_manifest.json")},
        },
    }
    manifest_path = ROOT / "program_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    standard_plan = next(x for x in program_entries if x["id"] == 153091)
    core_rows = sum(x["direct_course_rows"] for x in standard_plan["course_rows_by_module"] if x["name"] == "专业核心教育课程")
    readme = [
        "# 复旦大学物理学系 2026 级培养方案",
        "",
        "官方培养方案查询入口匿名可读；筛选结果为物理学系（DEPART_IDS=2571）、2026级，共11条。11份系级详情和全校公共方案466均返回HTTP 200，详情审核状态均为ACCEPTED。",
        "",
        "## 如何阅读",
        "",
        "从 `index.html` 选择学生类别和方案。完整要求由对应系级方案与 `2026级 公共方案`（ID 466）共同组成；每份系级方案都通过课程模块引用匹配到该公共方案。",
        "",
        "离线阅读 HTML 按官方详情 JSON 的 `courseModules` 树逐模块排版，并逐项列出模块自身的 `planCourses` 直接课程。父模块直接挂载的课程也保留。方案正文中的图片已下载到 `images/`，阅读版使用本地相对链接。原始JSON保留所有官方字段。",
        "",
        "## 范围与核验",
        "",
        f"- 系级方案：{len(program_entries)} 份；搜索页共 {expected_count} 条、{len(DISCOVERY.get('pagination', []))} 页。",
        f"- 公共方案：1份，ID 466。",
        f"- 系级方案直接课程行：{sum(x['direct_course_rows'] for x in program_entries)}；公共方案直接课程行：{public_entry['direct_course_rows']}（包括嵌套子模块直接课程 {public_entry['direct_course_rows_in_nested_modules']} 行）。",
        f"- 课程树完整性示例：标准本科方案153091共 {standard_plan['module_count']} 个模块、{standard_plan['direct_course_rows']} 行；“专业核心教育课程”模块直接挂载 {core_rows} 行，已逐门列入离线阅读版。公共方案466的69个顶层模块直接挂载 {public_entry['direct_course_rows_on_top_level_modules']} 行，嵌套模块另有 {public_entry['direct_course_rows_in_nested_modules']} 行，合计 {public_entry['direct_course_rows']} 行。",
        f"- 正文图片：{len(image_entries)}个唯一资源，全部可匿名下载。",
        "- 所有系级方案详情审核状态均由原始 `model.auditState` 核实；版本日期按原始 `effectiveOn` 与 `updatedDateTime` 记录。",
        "- 公开入口提供阅读/导出相关页面逻辑，但没有发现PDF文件响应；本目录提供可离线阅读HTML，不冒称教务系统签章PDF。",
        "",
        "## 文件",
        "",
        "- `program_manifest.json`：范围、版本、来源URL、状态、SHA-256、图片相对路径、模块直接课程核验记录。",
        "- `program_courses.json`：按方案、模块树和直接课程整理的整合索引，保留系级方案到公共方案模块的引用关系。",
        "- `sources/`：入口HTML、分页检索响应、匿名HTTP访问日志与图片源清单。",
        "- `programs/`：11份系级方案原始JSON。",
        "- `public/466.json`：公共方案原始JSON。",
        "- `printable/`：12份离线HTML阅读版。",
        "- `images/`：官方正文图片资源。",
        "- `SHA256SUMS.txt`：本目录其余文件的SHA-256校验表。",
        "",
        "## 来源",
        "",
        f"入口：{landing_url}",
        f"检索：{search_source_url}",
        "",
    ]
    readme_path = ROOT / "README.md"
    readme_path.write_text("\n".join(readme), encoding="utf-8")

    # Hash all final files except the checksum list itself. The manifest excludes its own digest.
    inventory = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.name == "SHA256SUMS.txt" or "__pycache__" in path.parts:
            continue
        rel = path.relative_to(ROOT).as_posix()
        inventory.append(f"{sha256(path)}  {rel}")
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(inventory) + "\n", encoding="utf-8")

    print(json.dumps({
        "root": str(ROOT), "search_rows": len(search_rows),
        "major_programs": [{"id": x["id"], "name": x["name"], "effective_on": x["effective_on"], "updated_at": x["updated_at"], "courses": x["direct_course_rows"], "html": x["printable_html"]} for x in program_entries],
        "public": {"id": public_entry["id"], "name": public_entry["name"], "courses": public_entry["direct_course_rows"], "html": public_entry["printable_html"]},
        "image_count": len(image_entries), "all_images_available": not missing_images,
        "checksum_entries": len(inventory), "manifest_sha256": sha256(manifest_path),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
