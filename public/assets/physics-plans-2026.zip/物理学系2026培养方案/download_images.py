from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
HOST = "https://fdjwgl.fudan.edu.cn"
TZ = timezone(timedelta(hours=8))


def now() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def extension(content_type: str | None, body: bytes) -> str:
    ct = (content_type or "").lower().split(";", 1)[0].strip()
    if ct == "image/png" or body.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if ct in ("image/jpeg", "image/jpg") or body.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if ct == "image/gif" or body.startswith((b"GIF87a", b"GIF89a")):
        return ".gif"
    if ct == "image/webp" or (len(body) > 12 and body[:4] == b"RIFF" and body[8:12] == b"WEBP"):
        return ".webp"
    if ct == "image/svg+xml" or body.lstrip().startswith(b"<svg"):
        return ".svg"
    return ".bin"


def collect_image_srcs(value, hits: set[str]) -> None:
    if isinstance(value, dict):
        for v in value.values():
            collect_image_srcs(v, hits)
    elif isinstance(value, list):
        for v in value:
            collect_image_srcs(v, hits)
    elif isinstance(value, str):
        for src in re.findall(r"<img\b[^>]*?\bsrc\s*=\s*['\"]([^'\"]+)['\"]", value, re.I):
            hits.add(src.strip())


sources: dict[str, set[str]] = {}
for folder in ("programs", "public"):
    for path in sorted((ROOT / folder).glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        hits: set[str] = set()
        collect_image_srcs(doc.get("programContent") or doc.get("document") or {}, hits)
        for src in hits:
            sources.setdefault(src, set()).add(path.stem)

log_path = ROOT / "sources" / "http_log.json"
log = json.loads(log_path.read_text(encoding="utf-8"))
images: dict[str, dict] = {}
for src in sorted(sources):
    record = {"source_url": src, "referenced_by_program_ids": sorted(sources[src]), "access_status": "unavailable", "downloaded_at": now()}
    # Fetch only same-site image paths explicitly present in the official JSON.
    if not src.startswith("/manager/ws/structured-document/load-images/"):
        record["access_status"] = "not_fetched_unexpected_source"
        images[src] = record
        continue
    url = HOST + src
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; public-program-research/1.0)"})
    entry = {"url": url, "method": "GET", "requested_at": now(), "auth": "none", "asset_for": record["referenced_by_program_ids"]}
    try:
        with urlopen(req, timeout=40) as response:
            body = response.read()
            ext = extension(response.headers.get("Content-Type"), body)
            rel = "images/" + Path(src).name + ext
            dest = ROOT / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(body)
            digest = hashlib.sha256(body).hexdigest()
            entry.update({"http_status": response.status, "content_type": response.headers.get("Content-Type"), "content_length": len(body), "sha256": digest, "access_status": "available", "relative_path": rel})
            record.update({"source_url": url, "relative_path": rel, "http_status": response.status, "content_type": response.headers.get("Content-Type"), "bytes": len(body), "sha256": digest, "access_status": "available"})
    except HTTPError as exc:
        payload = exc.read()
        status = "restricted" if exc.code in (401, 403, 429) else "http_error"
        entry.update({"http_status": exc.code, "content_type": exc.headers.get("Content-Type") if exc.headers else None, "content_length": len(payload), "sha256": hashlib.sha256(payload).hexdigest() if payload else None, "access_status": status, "error": str(exc)})
        record.update({"source_url": url, "http_status": exc.code, "access_status": status, "error": str(exc)})
    except (URLError, TimeoutError, OSError) as exc:
        entry.update({"access_status": "network_error", "error": f"{type(exc).__name__}: {exc}"})
        record.update({"source_url": url, "access_status": "network_error", "error": f"{type(exc).__name__}: {exc}"})
    log.append(entry)
    images[src] = record

(ROOT / "sources" / "http_log.json").write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / "sources" / "images_manifest.json").write_text(json.dumps(images, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(images, ensure_ascii=False, indent=2))
