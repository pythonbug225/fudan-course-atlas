# 复旦大学物理学系 2026 级培养方案

官方培养方案查询入口匿名可读；筛选结果为物理学系（DEPART_IDS=2571）、2026级，共11条。11份系级详情和全校公共方案466均返回HTTP 200，详情审核状态均为ACCEPTED。

## 如何阅读

从 `index.html` 选择学生类别和方案。完整要求由对应系级方案与 `2026级 公共方案`（ID 466）共同组成；每份系级方案都通过课程模块引用匹配到该公共方案。

离线阅读 HTML 按官方详情 JSON 的 `courseModules` 树逐模块排版，并逐项列出模块自身的 `planCourses` 直接课程。父模块直接挂载的课程也保留。方案正文中的图片已下载到 `images/`，阅读版使用本地相对链接。原始JSON保留所有官方字段。

## 范围与核验

- 系级方案：11 份；搜索页共 11 条、1 页。
- 公共方案：1份，ID 466。
- 系级方案直接课程行：1182；公共方案直接课程行：1386（包括嵌套子模块直接课程 313 行）。
- 课程树完整性示例：标准本科方案153091共 60 个模块、152 行；“专业核心教育课程”模块直接挂载 11 行，已逐门列入离线阅读版。公共方案466的69个顶层模块直接挂载 1073 行，嵌套模块另有 313 行，合计 1386 行。
- 正文图片：17个唯一资源，全部可匿名下载。
- 所有系级方案详情审核状态均由原始 `model.auditState` 核实；版本日期按原始 `effectiveOn` 与 `updatedDateTime` 记录。
- 公共模块引用：11份系级方案各至少有一个模块引用可匹配ID 466。物理学（相辉计划）方案153086另有7个原始引用ID在当前公共方案模块树中未找到；其模块及直接课程仍完整保留，并在清单中标为未解析，没有按名称猜配。
- 公开入口提供阅读/导出相关页面逻辑，但没有发现PDF文件响应；本目录提供可离线阅读HTML，不冒称教务系统签章PDF。

## 文件

- `program_manifest.json`：范围、版本、来源URL、状态、SHA-256、图片相对路径、模块直接课程核验记录。
- `program_courses.json`：按方案、模块树和直接课程整理的整合索引，保留系级方案到公共方案模块的引用关系。
- `sources/`：入口HTML、分页检索响应、匿名HTTP访问日志与图片源清单。
- `programs/`：11份系级方案原始JSON。
- `public/466.json`：公共方案原始JSON。
- `printable/`：12份离线HTML阅读版。
- `images/`：官方正文图片资源。
- `SHA256SUMS.txt`：本目录其余文件的SHA-256校验表。

## 来源

入口：https://fdjwgl.fudan.edu.cn/manager/bizType/2/page-center/major-program-search-view?skipAuth=1
检索：https://fdjwgl.fudan.edu.cn/manager/bizType/2/page-center/major-program-search-view/search?YEARS=2026&DEPART_IDS=2571&queryPage__=1%2C100
