from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
BASE = "https://fdjwgl.fudan.edu.cn/manager/bizType/2"
LANDING = BASE + "/page-center/major-program-search-view?skipAuth=1"
SEARCH_BASE = BASE + "/page-center/major-program-search-view/search"
TZ = timezone(timedelta(hours=8))


def now() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def fetch(url: str) -> tuple[bytes | None, dict]:
    """Anonymous GET only; no cookies, credentials, retries, or alternate routes."""
    entry = {"url": url, "method": "GET", "requested_at": now(), "auth": "none"}
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; public-program-research/1.0)"})
    try:
        with urlopen(req, timeout=40) as response:
            body = response.read()
            entry.update({
                "http_status": response.status,
                "content_type": response.headers.get("Content-Type"),
                "content_length": len(body),
                "sha256": hashlib.sha256(body).hexdigest(),
                "access_status": "available",
            })
            return body, entry
    except HTTPError as exc:
        body = exc.read()
        entry.update({
            "http_status": exc.code,
            "content_type": exc.headers.get("Content-Type") if exc.headers else None,
            "content_length": len(body),
            "sha256": hashlib.sha256(body).hexdigest() if body else None,
            "access_status": "restricted" if exc.code in (401, 403, 429) else "http_error",
            "error": str(exc),
        })
        return body or None, entry
    except (URLError, TimeoutError, OSError) as exc:
        entry.update({"access_status": "network_error", "error": f"{type(exc).__name__}: {exc}"})
        return None, entry


def save_body(rel: str, body: bytes) -> str:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(body)
    return hashlib.sha256(body).hexdigest()


ROOT.mkdir(parents=True, exist_ok=True)
log: list[dict] = []
fetches: dict[str, dict] = {}

body, record = fetch(LANDING)
log.append(record)
if body is None or record["access_status"] != "available":
    raise SystemExit(f"Landing unavailable: {record}")
save_body("sources/landing.html", body)
fetches["landing"] = record

all_rows: list[dict] = []
page_meta: list[dict] = []
page = 1
while True:
    url = f"{SEARCH_BASE}?YEARS=2026&DEPART_IDS=2571&queryPage__={page}%2C100"
    body, record = fetch(url)
    log.append(record)
    fetches[f"search_page_{page}"] = record
    if body is None or record["access_status"] != "available":
        break
    save_body(f"sources/college_search_page_{page}.json", body)
    result = json.loads(body.decode("utf-8"))
    rows = result.get("data", [])
    all_rows.extend(rows)
    meta = result.get("_page_", {})
    page_meta.append({"page": page, "returned": len(rows), "meta": meta})
    if not rows or page >= meta.get("totalPages", page):
        break
    page += 1
    time.sleep(0.2)

if len(all_rows) == 0:
    raise SystemExit("No public 2026 physics program rows were returned; inspect sources/http_log.json")

program_fetches: list[dict] = []
for row in all_rows:
    pid = int(row["ID"])
    url = f"{BASE}/major-program-search/info/{pid}"
    body, record = fetch(url)
    log.append(record)
    record["program_id"] = pid
    record["list_name"] = row.get("NAME_ZH")
    record["relative_path"] = f"programs/{pid}.json" if body and record["access_status"] == "available" else None
    if body and record["access_status"] == "available":
        save_body(record["relative_path"], body)
    program_fetches.append(record)
    time.sleep(0.15)

summary = {
    "created_at": now(),
    "scope": {"department_name": "物理学系", "department_id": 2571, "grade": "2026"},
    "discovery": {"public_landing_url": LANDING, "college_search_url": SEARCH_BASE + "?YEARS=2026&DEPART_IDS=2571&queryPage__=1%2C100"},
    "pagination": page_meta,
    "search_row_count": len(all_rows),
    "search_rows": all_rows,
    "program_fetches": program_fetches,
}
(ROOT / "sources" / "http_log.json").write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / "sources" / "discovery.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"root": str(ROOT), "rows": len(all_rows), "programs": [{"id": r.get("ID"), "name": r.get("NAME_ZH"), "major": r.get("MAJOR_NAME")} for r in all_rows], "fetched": [{"id": r.get("program_id"), "status": r.get("access_status"), "bytes": r.get("content_length"), "sha256": r.get("sha256")} for r in program_fetches]}, ensure_ascii=False, indent=2))
