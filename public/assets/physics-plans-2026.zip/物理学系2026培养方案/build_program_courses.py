from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parent
TZ = timezone(timedelta(hours=8))
MANIFEST_PATH = ROOT / "program_manifest.json"
MANIFEST = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def now() -> str:
    return datetime.now(TZ).isoformat(timespec="seconds")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def course_modules(nodes):
    for node in nodes or []:
        yield node
        yield from course_modules(node.get("children"))


def node_name(node: dict) -> str:
    typ = node.get("type")
    if isinstance(typ, dict) and typ.get("nameZh"):
        return typ["nameZh"]
    name = node.get("nameZh")
    if name:
        return name
    return "根模块" if str(node.get("level")) == "1" else f"未命名模块（ID {node.get('id')}）"


def module_course_rows(module: dict) -> list[dict]:
    return module.get("planCourses") or []


def course_key(row: dict) -> str:
    c = row.get("course") or {}
    return str(c.get("id") or c.get("code") or c.get("nameZh") or row.get("id") or "")


def course_code(row: dict):
    return (row.get("course") or {}).get("code")


def row_to_reference(row: dict, module: dict, module_path: list[str]) -> dict:
    c = row.get("course") or {}
    period = row.get("periodInfo") or c.get("periodInfo") or {}
    open_department = c.get("openDepartment") or row.get("openDepartment") or {}
    teach_lang = row.get("teachLang") or {}
    exam_mode = row.get("examMode") or {}
    return {
        "association_id": row.get("id"),
        "course_id": c.get("id"),
        "code": c.get("code"),
        "name_zh": c.get("nameZh"),
        "name_en": c.get("nameEn"),
        "credits": row.get("credits") if row.get("credits") is not None else c.get("credits"),
        "compulsory": row.get("compulsory"),
        "required_course": row.get("requiredCourse"),
        "integration_compulsory": row.get("integrationCompulsory"),
        "term_codes": row.get("terms") or [],
        "terms_text": row.get("termsText"),
        "suggested_terms_text": row.get("suggestTermsText"),
        "total_periods": period.get("total"),
        "periods_per_week": period.get("periodsPerWeek"),
        "weeks": period.get("weeks"),
        "theory_periods": period.get("theory"),
        "practice_periods": period.get("practice"),
        "experiment_periods": period.get("experiment"),
        "practice_credit": row.get("practiceCredit"),
        "experiment_credit": row.get("experimentCredit"),
        "aesthetic_credit": row.get("aestheticCredit"),
        "exam_mode": exam_mode.get("nameZh") if isinstance(exam_mode, dict) else exam_mode,
        "teaching_language": teach_lang.get("nameZh") if isinstance(teach_lang, dict) else teach_lang,
        "full_english": row.get("fullEnglish"),
        "open_department": open_department.get("nameZh") if isinstance(open_department, dict) else open_department,
        "module_id": module.get("id"),
        "module_name": node_name(module),
        "module_level": module.get("level"),
        "module_path": module_path,
        "remark": row.get("remark"),
        "source_course_fields": {
            "ai": c.get("ai"),
            "course_ascription_school": c.get("courseAscriptionSchool"),
            "old_course_code": c.get("oldCourseCode"),
            "flags": c.get("flags") or [],
        },
    }


def subtree_course_rows(node: dict) -> list[dict]:
    rows = list(module_course_rows(node))
    for child in node.get("children") or []:
        rows.extend(subtree_course_rows(child))
    return rows


def normalize_modules(nodes, parent_path, public_module_by_id, public_program_id, reference_registry, program_id):
    result = []
    for node in nodes or []:
        title = node_name(node)
        path = parent_path + [title]
        info = node.get("requireInfo") or {}
        limit = node.get("limitInfo") or {}
        direct = module_course_rows(node)
        ref_assoc = node.get("referenceCourseModuleAssoc")
        copy_assoc = node.get("copyCourseModuleAssoc")
        matched_public = []
        for assoc, matched_by in ((ref_assoc, "referenceCourseModuleAssoc"), (copy_assoc, "copyCourseModuleAssoc")):
            if assoc in public_module_by_id and program_id != public_program_id:
                source = public_module_by_id[assoc]
                source_rows = subtree_course_rows(source)
                source_keys = sorted({course_key(row) for row in source_rows if course_key(row)})
                matched_public.append({
                    "public_program_id": public_program_id,
                    "source_module_id": assoc,
                    "source_module_name": node_name(source),
                    "source_module_level": source.get("level"),
                    "source_course_rows_in_subtree": len(source_rows),
                    "source_unique_course_keys_in_subtree": len(source_keys),
                    "matched_by": matched_by,
                    "source_url": f"https://fdjwgl.fudan.edu.cn/manager/bizType/2/public-program-search/info/{public_program_id}",
                })
                group = reference_registry[(assoc, matched_by)]
                group["program_ids"].add(program_id)
                group["reference_count"] += 1
                group["module_ids"].add(node.get("id"))
        normalized = {
            "module_id": node.get("id"),
            "type_id": (node.get("type") or {}).get("id") if isinstance(node.get("type"), dict) else None,
            "name_zh": title,
            "name_en": (node.get("type") or {}).get("nameEn") if isinstance(node.get("type"), dict) else node.get("nameEn"),
            "level": node.get("level"),
            "parent_module_id": node.get("parentAssoc"),
            "reference": bool(node.get("reference")),
            "reference_course_module_assoc_id": ref_assoc,
            "copy_course_module_assoc_id": copy_assoc,
            "resolved_public_reference": matched_public[0] if matched_public else None,
            "public_reference_candidates": matched_public,
            "required_credits": info.get("requiredCredits"),
            "shown_required_credits": info.get("showRequiredCredits"),
            "required_submodule_count": info.get("requiredSubModuleNum"),
            "required_course_count": info.get("requiredCourseNum"),
            "require_all": info.get("requireAll"),
            "require_any": info.get("requireAny"),
            "integration_credits_required": info.get("integrationCreditsRequired"),
            "post_credits_required": info.get("postCreditsRequired"),
            "credits_upper_limit": limit.get("creditsUpperLimit"),
            "course_num_upper_limit": limit.get("courseNumUpperLimit"),
            "course_module_hidden": node.get("courseModuleHide"),
            "show_course": node.get("showCourse"),
            "merge_show": node.get("mergeShow"),
            "label_text": node.get("labelText"),
            "comment_text": node.get("commentText"),
            "remark": node.get("remark"),
            "course_row_count": len(direct),
            "course_association_count": len(node.get("planCourseAssocs") or []),
            "courses": [row_to_reference(row, node, path) for row in direct],
            "children": normalize_modules(node.get("children") or [], path, public_module_by_id, public_program_id, reference_registry, program_id),
        }
        result.append(normalized)
    return result


def flatten_normalized(modules):
    for module in modules:
        yield module
        yield from flatten_normalized(module.get("children") or [])


def normalized_course_rows(modules):
    for module in modules:
        yield from module.get("courses") or []
        yield from normalized_course_rows(module.get("children") or [])


def build_summary(raw: dict, meta: dict, public_module_by_id: dict, public_program_id: int, reference_registry):
    model = raw.get("model") or {}
    plan_id = int(model.get("id"))
    modules_raw = raw.get("courseModules") or []
    module_nodes = list(course_modules(modules_raw))
    direct_raw = [row for module in module_nodes for row in module_course_rows(module)]
    referenced_nodes = [m for m in module_nodes if m.get("reference")]
    unresolved = [m for m in referenced_nodes if m.get("referenceCourseModuleAssoc") not in public_module_by_id]
    module_tree = normalize_modules(modules_raw, [], public_module_by_id, public_program_id, reference_registry, plan_id)
    rows = list(normalized_course_rows(module_tree))
    if len(rows) != len(direct_raw):
        raise ValueError(f"Normalized course row count mismatch for plan {plan_id}: {len(rows)} vs {len(direct_raw)}")
    expected = meta["direct_course_rows"]
    if len(rows) != expected:
        raise ValueError(f"Manifest count mismatch for plan {plan_id}: {len(rows)} vs {expected}")
    keys = [course_key(row) for row in direct_raw]
    unique_codes = {course_code(row) for row in direct_raw if course_code(row)}
    top_rows = sum(len(module_course_rows(m)) for m in modules_raw)
    shared_source_rows = []
    shared_sum = 0
    for module in referenced_nodes:
        target = module.get("referenceCourseModuleAssoc")
        source = public_module_by_id.get(target)
        if source:
            source_rows = subtree_course_rows(source)
            shared_source_rows.extend(source_rows)
            shared_sum += len(source_rows)
    return {
        "id": plan_id,
        "name": model.get("nameZh"),
        "year": model.get("grade"),
        "major": (model.get("major") or {}).get("nameZh"),
        "major_id": (model.get("major") or {}).get("id"),
        "department": (model.get("department") or {}).get("nameZh"),
        "department_id": (model.get("department") or {}).get("id"),
        "plan_type": model.get("type"),
        "student_type": model.get("stdType"),
        "student_type_raw": model.get("stdType"),
        "major_direction": model.get("majorDirection"),
        "cultivate_type": model.get("cultivateType"),
        "study_form": model.get("studyForm"),
        "degree_type": model.get("degreeType"),
        "program_category": model.get("programCategory"),
        "integration_type": model.get("integrationType"),
        "duration_years": model.get("duration"),
        "terms_count": model.get("termsCount"),
        "effective_on": model.get("effectiveOn"),
        "invalid_on": model.get("invalidOn"),
        "audit_state": model.get("auditState"),
        "workflow_state": model.get("currentNode"),
        "updated_at": model.get("updatedDateTime"),
        "credits_total": model.get("credits"),
        "practice_credits": model.get("practiceCredits"),
        "flags": {
            "x2_plan": model.get("x2Plan"), "y2_plan": model.get("y2Plan"),
            "enhance_plan": model.get("enhancePlan"), "double_plan": model.get("doublePlan"),
        },
        "course_plan_id": (model.get("coursePlan") or {}).get("id"),
        "course_row_count_direct": len(rows),
        "course_row_count_on_top_level_modules": top_rows,
        "course_row_count_in_nested_modules": len(rows) - top_rows,
        "course_rows_on_reference_modules": sum(len(module_course_rows(m)) for m in referenced_nodes),
        "course_rows_in_shared_references": shared_sum,
        "course_rows_in_shared_references_nonoverlap": len({course_key(row) for row in shared_source_rows if course_key(row)}),
        "unresolved_reference_count": len(unresolved),
        "unresolved_references": [
            {"module_id": m.get("id"), "module_name": node_name(m), "level": m.get("level"),
             "reference_course_module_assoc_id": m.get("referenceCourseModuleAssoc"),
             "direct_course_rows_preserved": len(module_course_rows(m)),
             "direct_course_codes_preserved": [course_code(row) or (row.get("course") or {}).get("nameZh") for row in module_course_rows(m)]}
            for m in unresolved
        ],
        "reference_occurrence_count": len(referenced_nodes) - len(unresolved),
        "unique_course_keys": len({key for key in keys if key}),
        "unique_course_codes": len(unique_codes),
        "module_count": len(module_nodes),
        "top_level_module_count": len(modules_raw),
        "source_url": meta["source_url"],
        "source_sha256": meta["raw_sha256"],
        "raw_json_path": meta["raw_path"],
        "course_modules": module_tree,
        "course_rows_in_shared_references_note": "此字段按被引用的公共模块子树计数；若同时引用父模块和子模块，course_rows_in_shared_references会重复计入，而nonoverlap按course.id/代码去重。",
    }


def main() -> None:
    public_meta = MANIFEST["public_program"]
    public_id = int(public_meta["id"])
    public_raw = json.loads((ROOT / public_meta["raw_path"]).read_text(encoding="utf-8"))
    public_nodes = list(course_modules(public_raw.get("courseModules") or []))
    public_module_by_id = {m.get("id"): m for m in public_nodes}
    if len(public_module_by_id) != len(public_nodes):
        raise ValueError("Duplicate module IDs in public scheme")
    registry = defaultdict(lambda: {"program_ids": set(), "module_ids": set(), "reference_count": 0})

    # Public scheme course tree and exact source-linked courses.
    public_root = {
        "id": public_id, "name": (public_raw.get("model") or {}).get("nameZh"),
        "year": (public_raw.get("model") or {}).get("grade"),
        "effective_on": (public_raw.get("model") or {}).get("effectiveOn"),
        "updated_at": (public_raw.get("model") or {}).get("updatedDateTime"),
        "audit_state": (public_raw.get("model") or {}).get("auditState"),
        "workflow_state": (public_raw.get("model") or {}).get("currentNode"),
        "source_url": public_meta["source_url"], "source_sha256": public_meta["raw_sha256"],
        "raw_json_path": public_meta["raw_path"],
        "top_level_module_count": len(public_raw.get("courseModules") or []),
        "module_count": len(public_nodes),
    }
    public_modules = normalize_modules(public_raw.get("courseModules") or [], [], public_module_by_id, public_id, registry, public_id)
    public_rows = list(normalized_course_rows(public_modules))
    public_raw_rows = [row for module in public_nodes for row in module_course_rows(module)]
    public_top_rows = sum(len(module_course_rows(m)) for m in (public_raw.get("courseModules") or []))
    if len(public_rows) != len(public_raw_rows) or len(public_rows) != public_meta["direct_course_rows"]:
        raise ValueError(f"Public scheme course count mismatch: normalized={len(public_rows)}, source={len(public_raw_rows)}, manifest={public_meta['direct_course_rows']}")
    public_course_keys = {course_key(row) for row in public_raw_rows if course_key(row)}
    public_codes = {course_code(row) for row in public_raw_rows if course_code(row)}
    public_program = {
        **public_root,
        "course_row_count": len(public_rows),
        "course_row_count_on_top_level_modules": public_top_rows,
        "course_row_count_in_nested_modules": len(public_rows) - public_top_rows,
        "unique_course_keys": len(public_course_keys),
        "unique_course_codes": len(public_codes),
        "course_modules": public_modules,
    }

    # Major plan trees, including each direct planCourses array at every tree level.
    major_programs = []
    by_id = {int(x["id"]): x for x in MANIFEST["college_programs"]}
    for pid, meta in by_id.items():
        raw = json.loads((ROOT / meta["raw_path"]).read_text(encoding="utf-8"))
        major_programs.append(build_summary(raw, meta, public_module_by_id, public_id, registry))
    major_programs.sort(key=lambda x: [int(x["id"])])

    # Public reference index, grouped by target module and association type.
    cross_references = []
    total_references = 0
    unresolved = 0
    for (source_id, matched_by), info in sorted(registry.items(), key=lambda x: (x[0][0], x[0][1])):
        source = public_module_by_id[source_id]
        source_rows = subtree_course_rows(source)
        cross_references.append({
            "public_module_id": source_id,
            "public_module_name": node_name(source),
            "program_ids": sorted(info["program_ids"]),
            "referencing_module_ids": sorted(info["module_ids"]),
            "reference_count": info["reference_count"],
            "resolved": True,
            "matched_by": matched_by,
            "course_rows_including_descendants": len(source_rows),
            "unique_course_keys_including_descendants": len({course_key(row) for row in source_rows if course_key(row)}),
            "source_url": public_meta["source_url"],
        })
        total_references += info["reference_count"]
    unresolved = sum(p["unresolved_reference_count"] for p in major_programs)
    unresolved_references = [
        {"program_id": p["id"], "program_name": p["name"], **item}
        for p in major_programs for item in p["unresolved_references"]
    ]

    output = {
        "schema_version": "1.0",
        "created_at": now(),
        "scope": {
            "department": "物理学系", "department_id": 2571, "grade": 2026,
            "college_program_count": len(major_programs), "linked_public_program_count": 1,
            "public_program_id": public_id,
            "program_search_pagination": {
                "currentPage": 1, "rowsInPage": MANIFEST["scope"]["search_total_rows"],
                "rowsPerPage": 100, "totalRows": MANIFEST["scope"]["search_total_rows"],
                "totalPages": MANIFEST["scope"]["search_pages"],
            },
        },
        "public_program": public_program,
        "major_programs": major_programs,
        "cross_references": {
            "target_public_program_id": public_id,
            "references": cross_references,
            "reference_occurrence_count": total_references,
            "unresolved_reference_count": unresolved,
            "unresolved_references": unresolved_references,
            "all_major_programs_link_public_program": all(p["reference_occurrence_count"] > 0 for p in major_programs),
            "course_rows": "All course_modules[].courses list the direct planCourses for that exact node, including parent modules; referenced public module courses are available under public_program.course_modules and resolved_public_reference.",
        },
        "integrity": {
            "major_raw_course_rows": sum(p["course_row_count_direct"] for p in major_programs),
            "major_normalized_course_rows": sum(sum(1 for _ in normalized_course_rows(p["course_modules"])) for p in major_programs),
            "public_raw_course_rows": len(public_raw_rows),
            "public_normalized_course_rows": len(public_rows),
            "all_major_rows_match_raw_json": all(p["course_row_count_direct"] == by_id[p["id"]]["direct_course_rows"] for p in major_programs),
            "all_public_references_resolved": unresolved == 0,
            "public_nested_direct_course_rows_included": len(public_rows) - public_top_rows,
        },
    }
    output_path = ROOT / "program_courses.json"
    output_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")

    # Link the integration index from the primary source manifest and refresh checksums.
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    manifest["program_courses"] = {
        "path": "program_courses.json", "bytes": output_path.stat().st_size,
        "sha256": sha(output_path), "major_program_count": len(major_programs),
        "public_program_id": public_id, "major_course_rows": output["integrity"]["major_raw_course_rows"],
        "public_course_rows": len(public_rows), "unresolved_public_references": unresolved,
    }
    manifest.setdefault("public_program_association", {})["unresolved_reference_count"] = unresolved
    manifest["public_program_association"]["unresolved_references"] = unresolved_references
    manifest["public_program_association"]["all_major_programs_have_public_module_match"] = all(p["reference_occurrence_count"] > 0 for p in major_programs)
    manifest.setdefault("access_and_offline_status", {})["unresolved_module_references"] = unresolved
    MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    readme_path = ROOT / "README.md"
    readme = readme_path.read_text(encoding="utf-8")
    audit_note = "- 公共模块引用：11份系级方案各至少有一个模块引用可匹配ID 466。物理学（相辉计划）方案153086另有7个原始引用ID在当前公共方案模块树中未找到；其模块及直接课程仍完整保留，并在清单中标为未解析，没有按名称猜配。\n"
    if "- 公共模块引用：" not in readme:
        readme = readme.replace("- 所有系级方案详情审核状态均由原始 `model.auditState` 核实；版本日期按原始 `effectiveOn` 与 `updatedDateTime` 记录。\n", "- 所有系级方案详情审核状态均由原始 `model.auditState` 核实；版本日期按原始 `effectiveOn` 与 `updatedDateTime` 记录。\n" + audit_note)
        readme_path.write_text(readme, encoding="utf-8")

    sums = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or path.name == "SHA256SUMS.txt" or "__pycache__" in path.parts:
            continue
        sums.append(f"{sha(path)}  {path.relative_to(ROOT).as_posix()}")
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")
    print(json.dumps({
        "program_courses": str(output_path), "bytes": output_path.stat().st_size,
        "major_programs": len(major_programs), "major_course_rows": output["integrity"]["major_raw_course_rows"],
        "public_course_rows": len(public_rows), "public_top_level_course_rows": public_top_rows,
        "public_nested_course_rows": len(public_rows) - public_top_rows,
        "public_module_reference_occurrences": total_references,
        "unresolved_public_references": unresolved,
        "manifest_sha256": sha(MANIFEST_PATH), "checksum_entries": len(sums),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
