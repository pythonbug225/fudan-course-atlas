"""Validate graph provenance, node coverage and semantic boundaries; offline."""
import collections,csv,hashlib,json,pathlib,xml.etree.ElementTree as ET,zipfile
R=pathlib.Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text('utf-8-sig'))
g=read(R/'graph.json');offered=read(R.parent/'逐课程汇总.json');plans=read(R.parent/'官方资料/plan-manifest.json')
nodes={n['id']:n for n in g['nodes']};ids=set(nodes);errors=[]
assert len(ids)==len(g['nodes'])==177
assert {c['courseCode'] for c in offered}<=ids
assert ids=={c['courseCode'] for c in offered}|{r['courseCode'] for p in plans for r in p['courseRows']}
assert sum(n['scope']=='plan_only' for n in nodes.values())==10
assert nodes['CHIN70096']['level']==['研究生'] and nodes['ICLE20030']['level']==['本科']
assert not any(e['mandatory'] or e['credit_equivalence'] for e in g['edges'])
assert g['scope']['strict_prerequisite_edges_verified']==0
keys=set();degree=collections.Counter();dag=collections.defaultdict(list)
for e in g['edges']:
    assert e['source'] in ids and e['target'] in ids and e['source']!=e['target']
    assert e['type'] in g['relation_types'] and bool(e['directed'])==(e['type']!='content_link')
    key=(e['source'],e['target'],e['type']);assert key not in keys;keys.add(key)
    if not e['directed']:assert e['source']<e['target']
    assert e['reason'] and e['evidence']
    for ref in e['evidence']:assert ref['source'] in g['sources'] and ref['locator']
    if e['type']=='curriculum_sequence':
        assert any(ref['source'].startswith('FIGURE') for ref in e['evidence'])
        assert '研究生' not in nodes[e['source']]['level']+nodes[e['target']]['level']
        dag[e['source']].append(e['target'])
    else:assert e['status']=='proposed_needs_syllabus_review'
    degree.update([e['source'],e['target']])
visiting=set();done=set()
def visit(x):
    assert x not in visiting,'Official sequence cycle: '+x
    if x in done:return
    visiting.add(x)
    for y in dag[x]:visit(y)
    visiting.remove(x);done.add(x)
for x in ids:visit(x)
assert [n for n in ids if not degree[n]]==['100.900.2']
for p in g['pathways']:assert all(i in ids for i in p['course_ids'])
for src in g['sources'].values():
    assert (R/src['path']).is_file(),src['path']
for p in plans:
    src=g['sources']['FIGURE'+p['planId']]
    with zipfile.ZipFile(R/src['original_docx']) as z:assert z.read(src['word_media'])==(R/src['path']).read_bytes()
    assert hashlib.sha256((R/src['original_docx']).read_bytes()).hexdigest().upper()==p['sha256'].upper()
for name in ['语言文化方向.svg','商务汉语方向.svg']:ET.parse(R/name)
page=(R/'课程关系图谱.html').read_text('utf8');assert 'GRAPH_DATA_PLACEHOLDER' not in page and 'fetch(' not in page
embedded=page.split('<script id="graph-data" type="application/json">')[1].split('</script>')[0];assert json.loads(embedded)==g
with (R/'nodes.csv').open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==177
with (R/'edges.csv').open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==len(g['edges'])
result={'status':'passed','course_nodes':177,'original_offering_codes':167,'plan_only_codes':10,'edges':len(g['edges']),'edge_types':dict(collections.Counter(e['type'] for e in g['edges'])),'mandatory_prerequisites_verified':0,'unresolved_aggregate_course_codes':['100.900.2'],'checks':['Official ordering acyclic; no inferred mandatory prerequisites','Distinct codes and levels preserved; source references resolve','HTML embeds the same graph; CSV and SVG parse correctly'],'input_sha256':{'inventory':hashlib.sha256((R.parent/'逐课程汇总.json').read_bytes()).hexdigest(),'program_manifest':hashlib.sha256((R.parent/'官方资料/plan-manifest.json').read_bytes()).hexdigest()}}
(R/'validation.json').write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf8'));print(json.dumps(result,ensure_ascii=False))
