"""Build a sourced course graph from the published inventory and 2026 plans.
No network access. Course ordering is never treated as an enrolment requirement.
"""
import collections,csv,hashlib,html,json,pathlib,shutil
R=pathlib.Path(__file__).resolve().parent;P=R.parent
def read(p):return json.loads(p.read_text('utf-8-sig'))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode('utf8'))
def save(p,x):write(p,json.dumps(x,ensure_ascii=False,indent=2)+'\n')
courses=read(P/'逐课程汇总.json');plans=read(P/'官方资料/plan-manifest.json')
topics={'language':'汉语与语言能力','linguistics':'语言学与汉语本体','culture':'文学、历史与中国文化','business':'商务与经济','education':'国际中文教育','cross':'跨文化与国际传播','governance':'全球治理与公共政策','academic':'学术训练与研究方法','unresolved':'待补分班内容'}
groups={
'linguistics':'CHIN40071 CHIN60156 CHIN70092 CHIN70093 GEEC10198 ICLE10018 ICLE10019 ICLE20004 ICLE20007 ICLE20026 ICLE20028 ICLE20029 ICLE30003 ICLE30004 ICLE30005 ICLE30012 ICLE40007 ICLE60005 ICLE70001',
'business':'ICLE10012 ICLE20005 ICLE20006 ICLE20022 ICLE20023 ICLE20024 ICLE20025 ICLE30013 ICLE30014 ICLE30015 ICLE30016 ICLE30017 ICLE30018 ICLE30020 ICLE30021 ICLE30022 ICLE30023 ICLE40008 ICLE40009 ICLE40010 ICLE40011 ICLE40014 ICLE40015',
'education':'CHIN40072 CHIN40073 CHIN70094 CHIN70095 CHIN70096 ICLE20030 ICLE20031 ICLE30029 ICLE30030 ICLE30031 ICLE40016 ICLE40017 ICLE40019 ICLE40021 ICLE40024 ICLE50001 ICLE60004 ICLE60007 ICLE70002 ICLE70003 ICLE70004 ICLE70005',
'cross':'CHIN60155 ICLE10016 ICLE20009 ICLE40023 ICLE60006 ICLE60008 ICLE60009 ICLE60010',
'academic':'GECS10003 GECS10004 GEEC10200 GEEC10197 GEIN30001 CHIN60157 ICLE40012 ICLE40013 ICLE60003',
'language':'GECS10001 GECS10002 GECS10005 GECS10006 GECS10007 GECS10008 GEEC10195 GEEC10196 GEEC30007 ICLE10020 ICLE10021 ICLE10024 ICLE10025 ICLE10026 ICLE10027 ICLE10028 ICLE10029 ICLE10030 ICLE10031 ICLE20001 ICLE20002 ICLE20012 ICLE20013 ICLE20017 ICLE20018 ICLE20020 ICLE20021 ICLE20033 ICLE20034 ICLE20035 ICLE20036 ICLE20037 ICLE30001 ICLE30002 ICLE30028 ICLE40001 ICLE40018 ICLE40020'}
topic_map={c:t for t,v in groups.items() for c in v.split()}
nodes={c['courseCode']:{'id':c['courseCode'],'name':c['courseName'],'level':c['courseLevels'],'offered_terms':c['terms'],'teachers':[t['name'] for t in c['teachers']],'search_keys':c.get('searchKeys',{}),'scope':'offering','programs':[]} for c in courses}
sources={'OFFERINGS':{'title':'2025秋、2026春官方课程汇总','path':'../逐课程汇总.json','basis':'official_timetable'}}
for p in plans:
    pid=p['planId'];sources['PLAN'+pid]={'title':p['planName'],'path':'../官方资料/plan-manifest.json','url':p['detailUrl'],'basis':'official_plan_rows','docx_sha256':p['sha256']}
    sources['FIGURE'+pid]={'title':p['planName']+'·第七节课程体系配图','path':'source-figures/2026-plan-'+pid+'-curriculum.png','original_docx':'../官方资料/方案原件/'+p['docxFile'],'word_media':'word/media/document_image_rId'+('8' if pid=='152712' else '9')+'.png','basis':'official_figure_read_directly','note':'人工核读原件配图；箭头表示培养体系递进，未标明硬性选课条件。'}
    for i,row in enumerate(p['courseRows']):
        code=row['courseCode']
        if code not in nodes:nodes[code]={'id':code,'name':row['courseName'],'level':['本科'],'offered_terms':[],'teachers':[],'search_keys':{},'scope':'plan_only','programs':[]}
        item={'plan_id':pid,'module':row['module'],'compulsory_in_module':row['compulsory'],'terms_text':row['termsText'],'suggest_terms_text':row['suggestTermsText'],'source_ref':'PLAN'+pid,'json_pointer':'/'+str(plans.index(p))+'/courseRows/'+str(i)}
        if not any(all(a.get(k)==item[k] for k in item if k!='json_pointer') for a in nodes[code]['programs']):nodes[code]['programs'].append(item)
for n in nodes.values():
    n['topic']='unresolved' if n['id']=='100.900.2' else ('governance' if n['id'].startswith('GEEC200') or n['id'].startswith('MANA') else topic_map.get(n['id'],'culture'))
    n['topic_label']=topics[n['topic']];n['prerequisite_status']='尚未取得逐课硬性先修条款'
    n['scope']='offering_and_plan' if n['scope']=='offering' and n['programs'] else n['scope']
    n['notes']='这是非学历留学生课程的汇总条目，缺少具体班级内容，不为其编造课程关系。' if n['id']=='100.900.2' else ''
    extra_pinyin={'GEEC30007':('hskshuipingceshi','hskspcs'),'ICLE30028':('shangwuyingyu','swyy'),'ICLE40007':('hanziyanjiu','hzyj'),'ICLE20026':('hanyuxucishiwujiang','hyxcswj'),'ICLE20003':('lunyudaodu','lydd'),'ICLE20006':('kuaguogongsiyuzhongguoshichang','kggsyzgsc'),'MANA20005':('guojifazhanyuzhongguo','gjfzyzg'),'MANA20007':('quanqiushiyexiadezhongguomeitirongheyuchongtu','qqsyxdzgmtrhyct'),'GECS10004':('liuxueshengzhuanyehanyuii','lxszyhyii'),'ICLE30032':('zhongguominjiangushiyuminsuwenhua','zgmjgsymswh')}
    if n['id'] in extra_pinyin:
        py,initials=extra_pinyin[n['id']];n['search_keys']={'coursePinyin':py,'courseInitials':initials}
edges=[];edge_keys={};pathways=[]
def add(a,b,kind,reason,refs=None,context=''):
    assert a in nodes and b in nodes,(a,b)
    if kind=='content_link':a,b=sorted([a,b])
    key=(a,b,kind)
    refs=refs or [{'source':'OFFERINGS','locator':a+' / '+b}]
    if key in edge_keys:
        e=edge_keys[key]
        for r in refs:
            if r not in e['evidence']:e['evidence'].append(r)
        return e
    e={'id':'E'+hashlib.sha256('|'.join(key).encode()).hexdigest()[:12],'source':a,'target':b,'type':kind,'directed':kind!='content_link','mandatory':False,'status':'official_sequence_not_prerequisite' if kind=='curriculum_sequence' else 'proposed_needs_syllabus_review','reason':reason,'evidence':refs,'context':context,'credit_equivalence':False}
    edge_keys[key]=e;edges.append(e);return e
def chain(title,codes,figure=None,kind='curriculum_sequence'):
    codes=codes.split();pathways.append({'id':'P'+str(len(pathways)+1),'title':title,'course_ids':codes})
    for a,b in zip(codes,codes[1:]):
        if figure:refs=[{'source':'FIGURE'+figure,'locator':title+'：'+nodes[a]['name']+' → '+nodes[b]['name']}];reason='官方课程体系图中该主线按学期递进；作为修读顺序参考，不证明系统设有先修拦截。'
        else:
            refs=[{'source':'OFFERINGS','locator':a+' / '+b}];reason='按课程题名中的序号或上中下整理的递进建议；具体先修、衔接内容与难度须由当期大纲确认。'
            kind='recommended_preparation'
        add(a,b,kind,reason,refs)
chain('语言文化方向·阅读','ICLE10024 ICLE10025 ICLE20034 ICLE20035 ICLE30001 ICLE30002 ICLE40001','152712')
chain('语言文化方向·写作','ICLE10020 ICLE10021 ICLE20001 ICLE20002','152712')
chain('语言文化方向·听说','ICLE10028 ICLE10029','152712')
chain('中级汉语视听说','ICLE20012 ICLE20013','152712')
chain('古代汉语基础','ICLE30004 ICLE30005','152712')
chain('现当代文学','ICLE30010 ICLE30011','152712')
chain('古代文学','ICLE40002 ICLE40003','152712')
chain('语言文化方向·历史知识','ICLE20011 ICLE30008 ICLE40004','152712')
chain('商务方向·阅读','ICLE10026 ICLE10027 ICLE20036 ICLE20037','152713')
chain('商务方向·经济文献','ICLE30013 ICLE30014 ICLE40008','152713')
chain('商务方向·听说','ICLE10030 ICLE10031','152713')
chain('商务口语','ICLE20018 ICLE20033','152713')
chain('商务写作','ICLE20020 ICLE20021','152713')
chain('金融基础','ICLE30020 ICLE40015','152713')
chain('留学生英语','GEEC10195 GEEC10196','152712')
chain('中国概况','GESP10001 GESP10002','152712')
chain('涉外经济法规','ICLE30021 ICLE30022')
chain('国际贸易理论与实务','ICLE40010 ICLE40011')
chain('中国区域经济','ICLE30016 ICLE30017')
chain('留学生高级汉语','GECS10001 GECS10002')
chain('留学生专业汉语','GECS10003 GECS10004')
chain('汉语I与II','GECS10007 GECS10008')
chain('汉语水平进阶','GECS10005 GECS10006 GECS10001')
for pid in ['152712','152713']:
    for a,b in [('GECS10003','ICLE40012'),('GEIN30001','ICLE40012'),('ICLE40012','ICLE40013')]:
        add(a,b,'curriculum_sequence','方案科研训练主线由专业汉语、创新训练，经社会实践衔接毕业论文；课程图中的社会实践跨多个学期，此处汇总关联课程条目，不把活动阶段当作额外开课或硬性先修。',[{'source':'FIGURE'+pid,'locator':'右侧科研训练体系：专业汉语／创新与创业—社会实践—毕业论文'},{'source':'PLAN'+pid,'locator':'融合创新能力模块及课程体系与科研训练体系'}])
pathways.append({'id':'research','title':'学术训练主线','course_ids':['GECS10003','GEIN30001','ICLE40012','ICLE40013']})
prep=[
('ICLE10029','ICLE20012','听说基础有助于进入更综合的视听说训练。'),('ICLE10031','ICLE20017','商务听说基础可为中级商务听力提供语言准备。'),('ICLE10031','ICLE20018','商务听说基础可为中级商务口语提供语言准备。'),('ICLE10027','ICLE20020','商务语料阅读可为商务书面表达积累语言材料。'),('ICLE20037','ICLE30013','商务阅读与经济文献阅读在专业语料理解方面衔接。'),
('ICLE10019','ICLE20029','汉语基础语法可为现代汉语的系统学习提供准备。'),('ICLE20029','ICLE30003','现代汉语与现代汉语通论具有本体知识上的衔接，题名不能证明两课可替代。'),('ICLE20028','ICLE60005','一般语言学概念有助于理解汉外语言比较；此处跨层次，仅为知识联系。'),('ICLE20029','ICLE20031','汉语本体知识可支撑语法教学的讨论。'),('ICLE20029','ICLE30030','词汇与词汇教学需要相应汉语本体知识。'),('ICLE40007','ICLE40017','汉字研究的内容可支撑汉字教学设计。'),
('ICLE20024','ICLE30020','经济学基础有助于理解金融领域的问题。'),('ICLE20024','ICLE40010','经济学基础可支撑国际贸易理论的学习。'),('ICLE20024','ICLE20023','经济学分析视角可辅助理解当代中国经济；不是按实际开课年份判定先修。'),('ICLE20025','ICLE30018','世界经济背景有助于理解中国对外经济关系。'),('ICLE30020','ICLE40014','金融基础可支撑投资领域内容的理解。'),('ICLE30021','ICLE40010','涉外经济法规与贸易实务可互相提供规则背景。'),
('ICLE30004','ICLE40002','古代汉语能力有助于阅读古代文学材料。'),('ICLE20016','ICLE30010','文学艺术语料可为进入文学课程提供阅读准备。'),('ICLE20028','ICLE30029','语言学概念可辅助理解对外汉语教学原理。'),('ICLE20030','ICLE30029','学习者与心理方面的基础可支撑教学原理的学习。'),('ICLE30029','ICLE30031','教学原理可为教材分析与教学方法提供框架。'),('ICLE30031','ICLE40016','教材与教法的学习可为教学实践提供准备。'),
('ICLE40021','ICLE40024','二语习得视角可辅助理解汉语作为第二语言教学。'),('CHIN40072','CHIN40073','二语习得研究与对外汉语教学原理存在理论应用联系。'),('CHIN40073','CHIN70094','教学原理可为课堂教学技巧提供理论准备。'),('CHIN40073','CHIN70095','教学原理可为测试理论与实践提供课程目标背景。'),('CHIN60157','CHIN70094','教育技术可支持课堂教学工具的设计与使用。'),('ICLE60003','ICLE70004','研究方法可为教学调查与分析提供方法准备。'),('ICLE60003','ICLE70005','研究方法有助于理解教学测试与评估中的证据。'),('ICLE50001','ICLE60004','语言要素教学可为课堂案例研究提供观察维度。'),('ICLE70003','ICLE70004','课堂观察经历可为提出教学调查问题提供素材。'),
('ICLE10016','ICLE20009','跨文化交流概念可辅助理解跨文化管理。'),('ICLE40023','ICLE60008','跨文化交际可为区域国别中文传播提供交流视角。'),('ICLE60009','ICLE60010','理论与实践题名呈现知识应用联系；未取得研究生培养方案或先修条款。'),('GEEC10197','CHIN60157','计算机基础与现代教育技术有工具层面的联系；跨层次，不构成入学或选课条件。'),
('GEEC20011','GEEC20009','公共政策背景可帮助理解政策分析方法；没有当期大纲，方向只是学习建议。'),('GEEC20009','GEEC20015','政策分析方法可支持治理分析报告的组织。'),('GEEC20011','GEEC20015','公共政策概念可支持治理分析报告。'),('GEEC20012','GEEC20015','国际组织视角可作为治理分析报告的背景。'),('MANA20006','GEEC20015','数字政府建设可作为公共治理报告的专题。'),('ICLE10008','MANA20005','国际关系背景可辅助理解国际发展议题。'),('GEEC10200','ICLE40012','学术汉语表达可帮助组织实践报告。'),('ICLE20001','GECS10003','写作训练与专业汉语的学术规范训练相互支撑；并非两课的正式先修安排。')]
for a,b,reason in prep:add(a,b,'recommended_preparation',reason,context='依据课程题名、学科一般关联与已公布课程设置推断；未核阅逐班教学大纲，不作为选课资格判断。')
links=[
('CHIN40071','ICLE20029','同属现代汉语研究内容，但研究生与本科目标不同。'),('CHIN40072','ICLE40021','同属第二语言习得内容，属于不同课程代码。'),('CHIN40073','ICLE30029','同名教学原理课程分别为研究生、本科，不认定学分互认。'),('CHIN70096','ICLE20030','同名教育心理学分别属研究生与本科，不合并教师及教学要求。'),('CHIN60155','ICLE40023','跨文化交际学与跨文化交际共享内容域，具体范围待大纲确认。'),('CHIN70093','ICLE40007','同名汉字研究分别属研究生、本科。'),('CHIN70095','ICLE70005','测试理论与教学评估在评价问题上相关。'),('CHIN70092','GEEC10198','汉语语音研究与上海话可在语音或方言问题上联系，非同一课程。'),('CHIN60156','ICLE20031','现代汉语语法研究与语法教学在语法内容上联系。'),('ICLE70001','ICLE60007','心理语言学与外语教育心理学共享语言学习者视角。'),
('ICLE40018','GECS10002','均涉及高级汉语能力，但研究生与本科课程的目标、语言背景和考核须分别确认，不认定等价。'),
('ICLE10003','ICLE10005','书法与篆刻共享汉字艺术实践内容。'),('GEEC10199','GEEC10203','古诗词诵读与诗乐艺术在诗歌、声音和审美方面相邻。'),('ICLE10010','ICLE40006','戏曲与电影均可从表演和文化表达角度比较。'),('ICLE20027','ICLE40006','两门电影课程共享中文影视与文化内容，但不认定等价。'),('ICLE10006','ICLE30032','神话传说与民间故事均涉及叙事及传统文化。'),('ICLE20008','ICLE30032','民俗文化与民间故事在民间文化内容上相邻。'),('ICLE10001','ICLE20003','中国哲学与论语导读在思想文化内容上相关。'),('ICLE10011','ICLE10014','传统建筑文化可与文化地理的空间视角联系。'),('ICLE10009','ICLE10014','旅游文化与文化地理共享区域和地方文化视角。'),('ICLE20010','ICLE10014','人文地理知识与文化地理共享空间和人文背景。'),('ICLE10007','ICLE10015','传统医学文化与汉语及中国文化共享文化理解内容。'),('ICLE10013','ICLE20011','历史名人与历史知识文选在历史背景方面相邻。'),('ICLE40004','ICLE30008','古代与近现代史在历史内容上相接；官方图的学习顺序另列，不能以历史年代推断选课顺序。'),('ICLE30008','ICLE30009','近现代历史与中华人民共和国史有时代内容上的联系。'),('ICLE30007','ICLE30010','现当代名作选与现当代文学课程共享文学作品内容。'),('ICLE40005','ICLE40002','古代名作选与古代文学课程共享古典作品内容。'),('ICLE30019','ICLE30011','中外文学比较可与现当代文学形成作品比较视角。'),('GECC10084','GEEC10204','中西文化交流与近代上海专题在近代交流史上相邻。'),('CHIN70002','ICLE60002','中华经典、美典与文化经典共享经典阅读内容。'),('ICLE40022','ICLE50002','中华文化与传播可与文化技能的实践内容联系。'),('GESP10001','GESP20001','中国概况课程不同层次、代码和对象，内容相关但不互相替代。'),('GESP20001','GESP20002','中文与全英文中国概况在背景内容上相关，但授课语言及对象不同。'),
('ICLE10012','ICLE40009','经贸汉语与商务文化在商务情境及表达方面相邻。'),('ICLE20005','ICLE30015','商务案例与商贸战略可从案例及决策视角联系。'),('ICLE20006','ICLE40014','跨国公司与中国市场、市场与投资共享市场主题。'),('ICLE30016','ICLE20023','区域经济与中国经济共享中国经济的空间背景。'),('ICLE20022','ICLE30013','商务文选与经济文献阅读共享专业文本阅读。'),('ICLE30023','ICLE20021','经济应用文与商务写作共享专业书面表达。'),('ICLE30028','ICLE10012','商务英语与经贸汉语可在跨语言商务情境中联系。'),
('ICLE60006','ICLE60008','国别地域文化为区域国别传播提供文化背景。'),('ICLE60001','ICLE70002','国际汉学与国际中文教育史共享海外中文及知识传播的历史视角。'),('ICLE40019','ICLE40024','国际中文教育专题与第二语言教学属于相关教学研究领域。'),('ICLE40017','ICLE50001','汉字教学属于语言要素教学的相关内容。'),('ICLE40020','ICLE60005','专业外语与汉外对比在跨语言分析方面可联系。'),('GEEC10195','ICLE30028','通用英语与商务英语存在语言能力方面的联系，未核定水平门槛。'),('GEEC30007','GECS10001','HSK测试与高级汉语存在能力测评联系；不认定任何课程可替代证书要求。'),
('GEEC20013','GEEC20011','廉政分析与公共政策共享治理议题。'),('GEEC20014','MANA20005','可持续发展与国际发展共享发展议题。'),('GEEC20016','MANA20006','科技治理与数字政府共享技术与治理议题。'),('MANA20007','ICLE60009','全球中国媒体与中文国际传播共享媒体及跨文化传播问题。')]
for a,b,reason in links:add(a,b,'content_link',reason,context='基于题名与学科内容域的非定向联系，须以大纲复核；不说明先后、替代或学分互认。')
# Unmapped domain courses remain visible, with a loose thematic link rather than an invented prerequisite.
hubs={'language':'ICLE10024','linguistics':'ICLE20029','culture':'ICLE30006','business':'ICLE20024','education':'ICLE30029','cross':'ICLE10016','governance':'GEEC20011','academic':'ICLE40013'}
connected={c for e in edges for c in [e['source'],e['target']]}
for n in nodes.values():
    if n['id'] not in connected and n['topic']!='unresolved':
        hub=hubs[n['topic']]
        if hub!=n['id']:add(n['id'],hub,'content_link','课程题名同属“'+topics[n['topic']]+'”内容域；这里只提供主题导航，具体交集待教学大纲复核。',context='宽泛主题联系，不表示两课目标、难度或内容相同。')
graph={'schema_version':'1.0.0','generated_on':'2026-11-19','title':'国际文化交流学院课程关系图谱','scope':{'offering_terms':['2025秋','2026春'],'program_grade':'2026','offering_course_codes':len(courses),'plan_only_course_codes':sum(n['scope']=='plan_only' for n in nodes.values()),'total_course_codes':len(nodes),'strict_prerequisite_edges_verified':0,'coverage_note':'覆盖原167个开课代码，另补两份2026方案中未出现在原课表的课程。含不同层次及同名课程，均按代码区分。'},'relation_types':{'curriculum_sequence':{'label':'官方培养顺序','directed':True,'mandatory':False,'description':'方案课程体系配图或科研训练文字提供的递进主线；不等同硬性先修。'},'recommended_preparation':{'label':'建议知识准备','directed':True,'mandatory':False,'description':'按题名、序号及一般学科联系提出的学习准备建议，待大纲确认。'},'content_link':{'label':'内容联系','directed':False,'mandatory':False,'description':'共享内容域或方法的非定向联系，不表示先修、等价或学分互认。'}},'limitations':['尚未取得可核验的逐课硬性先修表，不能据本图判断选课资格。','不以课程代码大小、2025秋与2026春的实际开课先后推断先修。','研究生课程未取得对应培养方案，相关关系主要为题名推断，须补大纲和教师确认。','方案配图的社会实践阶段跨多个学期，图中课程节点仅为对应课程条目。','每门课的具体教学内容与平行班要求仍须当期大纲复核。'],'sources':sources,'topics':topics,'nodes':sorted(nodes.values(),key=lambda n:n['id']),'edges':edges,'pathways':pathways}
save(R/'graph.json',graph)
for filename,fields,rows in [('nodes.csv',['id','name','topic_label','level','scope','offered_terms','teachers'],graph['nodes']),('edges.csv',['id','source','source_name','target','target_name','type','directed','mandatory','reason','evidence','context'],[{**e,'source_name':nodes[e['source']]['name'],'target_name':nodes[e['target']]['name']} for e in edges])]:
    import io
    out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore',lineterminator='\n');w.writeheader()
    for row in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items() if k in fields})
    write(R/filename,'\ufeff'+out.getvalue())
counts=dict(collections.Counter(e['type'] for e in edges));print(json.dumps({'nodes':len(nodes),'edges':len(edges),'types':counts,'plan_only':[n['id'] for n in nodes.values() if n['scope']=='plan_only']},ensure_ascii=False))
