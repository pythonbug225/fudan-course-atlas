"""Render standalone SVG roadmaps, GitHub Mermaid documentation and offline HTML."""
import pathlib,json,html,hashlib,collections
R=pathlib.Path(__file__).resolve().parent
g=json.loads((R/'graph.json').read_text('utf8'));N={n['id']:n for n in g['nodes']}
def esc(s):return html.escape(str(s),quote=True)
def write(name,s):(R/name).write_bytes(s.encode('utf8'))
def card(code,x,y,w=132):
    text=N[code]['name'];split=max(text.rfind('（'),text.rfind('('));lines=([text[:split],text[split:]] if len(text)>8 and split>0 else [text[i:i+8] for i in range(0,len(text),8)])
    out=[f'<g><rect x="{x}" y="{y}" width="{w}" height="64" rx="7" fill="#f5f8fc" stroke="#b8c8d9"/><text x="{x+w/2}" y="{y+16}" text-anchor="middle" font-size="10" fill="#53687c">{esc(code)}</text>']
    for i,line in enumerate(lines):out.append(f'<text x="{x+w/2}" y="{y+35+i*16}" text-anchor="middle" font-size="13" fill="#15334d">{esc(line)}</text>')
    return ''.join(out)+'</g>'
def roadmap(filename,title,rows):
    width=1450;col=154;left=170;top=128;rh=99;height=top+len(rows)*rh+100
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc"><title id="title">{esc(title)}</title><desc id="desc">仅显示官方课程体系主线；箭头是培养顺序，不代表强制先修。完整177课程及内容联系见graph.json与交互图谱。</desc><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#2678ad"/></marker></defs><rect width="100%" height="100%" fill="white"/><g font-family="Microsoft YaHei, Noto Sans CJK SC, sans-serif"><text x="35" y="40" font-size="25" fill="#15334d">{esc(title)}</text><text x="35" y="70" font-size="14" fill="#53687c">按2026级官方培养方案配图整理 · 方案学期1–8 · 箭头表示培养顺序，不能用于判断选课资格</text>']
    for t in range(1,9):
        x=left+(t-1)*col;s.append(f'<text x="{x+66}" y="108" text-anchor="middle" fill="#53687c" font-size="14">第{t}学期</text><line x1="{x-9}" y1="118" x2="{x-9}" y2="{height-75}" stroke="#e7edf2"/>')
    for i,(label,placements) in enumerate(rows):
        y=top+i*rh;s.append(f'<text x="30" y="{y+35}" fill="#15334d" font-size="14">{esc(label)}</text>')
        pos={c:(left+(t-1)*col,y) for c,t in placements}
        for e in g['edges']:
            if e['type']=='curriculum_sequence' and e['source'] in pos and e['target'] in pos:
                a=pos[e['source']];b=pos[e['target']]
                if b[0]-a[0]>col+1:
                    s.append(f'<path d="M{a[0]+133},{a[1]+32} C{a[0]+170},{a[1]-18} {b[0]-45},{b[1]-18} {b[0]-6},{b[1]+32}" fill="none" stroke="#2678ad" stroke-width="2" marker-end="url(#arrow)"/>')
                else:s.append(f'<line x1="{a[0]+133}" y1="{a[1]+32}" x2="{b[0]-6}" y2="{b[1]+32}" stroke="#2678ad" stroke-width="2" marker-end="url(#arrow)"/>')
        for c,(x,yy) in pos.items():s.append(card(c,x,yy))
    s.append(f'<text x="35" y="{height-45}" font-size="13" fill="#53687c">社会实践在原图中跨多个学期持续开展；这里的课程节点仅对应方案课程条目。</text><text x="35" y="{height-22}" font-size="13" fill="#53687c">仅为主线视图，不表示全部课程或必修要求；学期与专业路径以原方案及当期教务说明为准。</text></g></svg>');write(filename,''.join(s))
roadmap('语言文化方向.svg','汉语言 · 对外语言文化方向',[
('阅读能力',list(zip('ICLE10024 ICLE10025 ICLE20034 ICLE20035 ICLE30001 ICLE30002 ICLE40001'.split(),range(1,8)))),
('写作能力',list(zip('ICLE10020 ICLE10021 ICLE20001 ICLE20002'.split(),range(1,5)))),
('听说／视听说',[('ICLE10028',1),('ICLE10029',2),('ICLE20012',3),('ICLE20013',4)]),
('古代汉语',[('ICLE30004',5),('ICLE30005',6)]),('文学课程',[('ICLE30010',5),('ICLE30011',6),('ICLE40002',7),('ICLE40003',8)]),
('历史知识',[('ICLE20011',3),('ICLE30008',5),('ICLE40004',7)]),('科研训练',[('GECS10003',2),('GEIN30001',3),('ICLE40012',7),('ICLE40013',8)])])
roadmap('商务汉语方向.svg','汉语言 · 对外商务汉语方向',[
('商务阅读',list(zip('ICLE10026 ICLE10027 ICLE20036 ICLE20037'.split(),range(1,5)))),('经济文献',[('ICLE30013',5),('ICLE30014',6),('ICLE40008',7)]),
('商务听说',[('ICLE10030',1),('ICLE10031',2),('ICLE20018',3),('ICLE20033',4)]),('商务写作',[('ICLE20020',3),('ICLE20021',4)]),
('中级视听说',[('ICLE20012',3),('ICLE20013',4)]),('金融基础',[('ICLE30020',6),('ICLE40015',7)]),('科研训练',[('GECS10003',2),('GEIN30001',3),('ICLE40012',7),('ICLE40013',8)])])
parts=['# 国际文化交流学院课程关系图谱','','覆盖原2025秋／2026春167个课程代码，以及2026级两份培养方案补出的10个课程代码，共177个节点。按课程代码保留本科、研究生和同名课差异。','','- [离线交互图谱](课程关系图谱.html)：下载本目录后打开；可搜索课程、查看邻接关系与证据。','- [语言文化方向主线图](语言文化方向.svg) · [商务汉语方向主线图](商务汉语方向.svg)。','- [关系数据 graph.json](graph.json) · [课程节点 CSV](nodes.csv) · [关系边 CSV](edges.csv) · [校验结果](validation.json)。','','## 关系怎样理解','','| 关系 | 方向 | 依据及边界 |','| --- | --- | --- |','| 官方培养顺序 | 有向 | 原件课程体系图或科研训练文字的递进主线；不作为硬性先修。 |','| 建议知识准备 | 有向 | 题名、序号及一般学科关联，未核阅逐班大纲；属于待确认建议。 |','| 内容联系 | 无向 | 共享主题、方法或材料，不表示先后、同课、替代或学分互认。 |','','当前未取得可核验的逐课硬性先修条款，因此图中没有“已确认必须先修”关系。不能把课号大小、开课时间先后或箭头直接当作选课资格条件。研究生课程主要为内容关联，未用本科方案推断研究生培养顺序。','','## 官方主线','','下面的实线箭头只表示培养顺序；不是系统先修限制。完整逐条依据保存在graph.json的evidence中。']
for title,ids in [('语言文化·阅读','ICLE10024 ICLE10025 ICLE20034 ICLE20035 ICLE30001 ICLE30002 ICLE40001'),('商务汉语·阅读与专业文献','ICLE10026 ICLE10027 ICLE20036 ICLE20037'),('科研训练','GECS10003 ICLE40012 ICLE40013')]:
    parts+=['','### '+title,'','```mermaid','flowchart LR']
    for c in ids.split():parts.append('  '+c+'["'+N[c]['name']+'<br/>'+c+'"]')
    for a,b in zip(ids.split(),ids.split()[1:]):parts.append('  '+a+' -->|培养顺序| '+b)
    parts.append('```')
parts+=['','## 内容与学习准备','','- 语言学与教学：现代汉语、汉字和语法等本体知识，可与语法／词汇／汉字教学以及教材教法联系。教学原理、课堂案例、观察实践、调查与评估形成理论到实践的方法链；这些跨课边属于学习建议。','- 商务经济：经济学基础与金融、国际贸易、投资等主题关联；商务阅读、写作及经济文献阅读形成专业语言内容的联系。','- 历史文化与传播：古代汉语与古代文学、诗词与诗乐、民俗与民间故事、交流史与上海专题等保留为内容联系。历史课程的学习顺序按官方图，不按历史年代自行调整。','- 公共治理：公共政策、分析方法、治理报告、国际组织、廉政、数字政府与科技治理形成主题联系。','- 同名课：例如本科ICLE20030与研究生CHIN70096“教育心理学”分别建节点，内容联系不代表学分互认。','','## 来源及适用范围','','本次直接读取Word内的课程体系配图，补上了纯文本提取无法覆盖的图片证据：','', '- [语言文化方向原件配图](source-figures/2026-plan-152712-curriculum.png)','- [商务汉语方向原件配图](source-figures/2026-plan-152713-curriculum.png)','- [此前官方课程与教学班汇总](../逐课程汇总.json)','- [2026方案列课与原件校验信息](../官方资料/plan-manifest.json)','','10个新增节点只说明出现在方案中，不声称它们已在2025秋／2026春开课。非学历留学生课程100.900.2是汇总条目，缺少班级细目，保持关系待补。社会实践在原图中跨多个学期开展，此处汇总到社会实践（报告）课程节点，不把每次活动虚构为独立课程。','','## 维护与复现','','运行 `python build_graph.py`、`python build_views.py`、`python validate_graph.py`。`build_graph.py`包含逐条关系理由和出处；新增官方先修条款时应添加独立的强制关系类型及直接证据，不把现有推断边升级为强制条件。','','当前边数：'+str(len(g['edges']))+'；分类：'+json.dumps(dict(collections.Counter(e['type'] for e in g['edges'])),ensure_ascii=False)+'。']
write('README.md',('\n'.join(parts)+'\n').replace('## 官方主线','## 两方向主线总览\n\n![对外语言文化方向主线](语言文化方向.svg)\n\n![对外商务汉语方向主线](商务汉语方向.svg)\n\n## 官方主线',1))
template=(R/'viewer-template.html').read_text('utf8');write('课程关系图谱.html',template.replace('GRAPH_DATA_PLACEHOLDER',json.dumps(g,ensure_ascii=False).replace('</','<\\/')))
